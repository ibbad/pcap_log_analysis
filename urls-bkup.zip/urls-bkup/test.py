#! usr/bin/python
import threading
import time

def myfunc(a=None):
    print("my func started with a=%s started\n" %a)
    time.sleep(10)
    print("my func with a=%s stopped\n" % a)


class FuncThread(threading.Thread):
    def __init__(self, target,*args, **kwargs):
        self._target=target
        self._args=args
        self._kwargs=kwargs
        threading.Thread.__init__(self)

    def run(self):
        self._target(*self._args, **self._kwargs)

FuncThread(myfunc,1).start()
FuncThread(myfunc,2).start()
FuncThread(myfunc,3).start()
FuncThread(myfunc,a=4).start()
FuncThread(myfunc,a=5).start()
